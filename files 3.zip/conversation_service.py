"""
services/conversation_service.py
=================================
Persistent per-user conversation storage using JSON files.

Each user gets their own file:  conversation_store/<user_id>.json

Structure:
  {
    "user_id": "uuid-...",
    "messages": [
      {"role": "user",      "content": "...", "timestamp": "2024-..."},
      {"role": "assistant", "content": "...", "timestamp": "2024-..."},
      ...
    ]
  }

Why JSON files and not in-memory list (your original memory_logs)?
  - In-memory list dies on every server restart.
  - Every user shares the same list in your original code → data leak risk.
  - JSON files persist across restarts and are isolated per user.

Production upgrade path:
  Swap the JSON read/write for CosmosDB calls (same interface, just different backend).
  The rest of the codebase doesn't change.
"""
import json
import os
from datetime import datetime, timezone
from typing import List, Optional

from core.config import CONVERSATIONS_DIR, MAX_HISTORY_TURNS
from models.chat import ChatMessage


# ── Helpers ───────────────────────────────────────────────────────────────────
def _user_file(user_id: str) -> str:
    os.makedirs(CONVERSATIONS_DIR, exist_ok=True)
    return os.path.join(CONVERSATIONS_DIR, f"{user_id}.json")


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


# ── Public API ────────────────────────────────────────────────────────────────
def load_conversation(user_id: str) -> List[ChatMessage]:
    """
    Load the full conversation history for a user.
    Returns [] for a brand-new user (no file yet).
    """
    path = _user_file(user_id)
    if not os.path.exists(path):
        return []
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    return [ChatMessage(**m) for m in data.get("messages", [])]


def save_message(user_id: str, role: str, content: str) -> None:
    """
    Append a single message to the user's conversation file.
    Roles: "user" | "assistant"
    """
    path = _user_file(user_id)

    # Load existing
    if os.path.exists(path):
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
    else:
        data = {"user_id": user_id, "messages": []}

    data["messages"].append({
        "role":      role,
        "content":   content,
        "timestamp": _now(),
    })

    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


def get_recent_history(user_id: str, max_turns: int = MAX_HISTORY_TURNS) -> List[dict]:
    """
    Returns the last `max_turns` full turns (user + assistant pairs)
    as a list of {"role": ..., "content": ...} dicts, ready to pass to OpenAI.

    Why limit history?
      - Azure OpenAI has a context window limit.
      - Sending ALL history can push retrieved chunks out of the window.
      - 10 turns = 20 messages is enough for coherent multi-turn dialogue.
    """
    messages = load_conversation(user_id)
    # Take last (max_turns * 2) raw messages (each turn = 1 user + 1 assistant)
    recent = messages[-(max_turns * 2):]
    return [{"role": m.role, "content": m.content} for m in recent]


def clear_conversation(user_id: str) -> None:
    """Wipe the user's conversation history (used by DELETE /chat/history)."""
    path = _user_file(user_id)
    if os.path.exists(path):
        os.remove(path)
