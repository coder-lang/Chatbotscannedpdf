"""
scripts/ingest_pdfs.py
=======================
One-time setup script. Run this ONCE before starting the FastAPI server.

Steps:
  Step 1 — OCR all PDFs → combined_output.txt  (Azure Document Intelligence)
  Step 2 — Parse chunks + build ChromaDB index  (Azure OpenAI Embeddings)

Usage:
  cd chatbot/
  python scripts/ingest_pdfs.py

After this script completes successfully, start the server with:
  uvicorn main:app --reload
"""
import sys
import os

# Allow imports from the project root
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from services.ocr_service import process_all_pdfs
from services.vector_service import build_or_load_vectorstore
from core.config import OUTPUT_TXT_FILE


def main():
    print("=" * 60)
    print("STEP 1: OCR — Extracting text from scanned PDFs")
    print("=" * 60)
    process_all_pdfs()

    if not os.path.exists(OUTPUT_TXT_FILE):
        print(f"\n[ERROR] OCR output not found at: {OUTPUT_TXT_FILE}")
        print("Check your INPUT_PDF_FOLDER and Azure DI credentials.")
        sys.exit(1)

    print("\n" + "=" * 60)
    print("STEP 2: INDEXING — Building ChromaDB vectorstore")
    print("=" * 60)
    vectorstore = build_or_load_vectorstore()
    print(f"\n✅ Ingestion complete. ChromaDB is ready.")
    print("You can now start the server: uvicorn main:app --reload")


if __name__ == "__main__":
    main()
