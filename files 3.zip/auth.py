"""
routers/auth.py
===============
POST /auth/register  — create a new account, returns user_id
POST /auth/login     — verify credentials, returns JWT
"""
from fastapi import APIRouter, HTTPException, status

from core.security import create_access_token
from models.user import LoginRequest, RegisterRequest, TokenResponse
from services.user_store import authenticate_user, register_user

router = APIRouter(prefix="/auth", tags=["Auth"])


@router.post("/register", response_model=TokenResponse, status_code=status.HTTP_201_CREATED)
def register(body: RegisterRequest):
    """
    Create a new user account.
    The returned JWT + user_id can be used immediately.
    """
    user_id = register_user(body.name, body.email, body.password)
    if user_id is None:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="An account with this email already exists.",
        )
    token = create_access_token(user_id=user_id, email=body.email)
    return TokenResponse(access_token=token, user_id=user_id)


@router.post("/login", response_model=TokenResponse)
def login(body: LoginRequest):
    """
    Login with email + password. Returns a JWT.
    The user_id embedded in the JWT is used server-side to load conversation history.
    The client does NOT need to send user_id manually on any subsequent request.
    """
    record = authenticate_user(body.email, body.password)
    if not record:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid email or password.",
        )
    token = create_access_token(user_id=record["user_id"], email=body.email)
    return TokenResponse(access_token=token, user_id=record["user_id"])
