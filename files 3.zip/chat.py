"""
routers/chat.py
===============
POST   /chat          — send a message, get a RAG-grounded response
GET    /chat/history  — retrieve full conversation history for the current user
DELETE /chat/history  — clear history for the current user
"""
from fastapi import APIRouter, Depends, Request

from core.dependencies import get_current_user
from models.chat import ChatRequest, ChatResponse, HistoryResponse
from services.chat_service import chat
from services.conversation_service import clear_conversation, load_conversation

router = APIRouter(prefix="/chat", tags=["Chat"])


@router.post("", response_model=ChatResponse)
async def send_message(
    body: ChatRequest,
    request: Request,
    current_user: dict = Depends(get_current_user),
):
    """
    Main chat endpoint.

    - JWT is validated by `get_current_user` dependency — user_id is extracted automatically.
    - Conversation history is loaded from disk (per user_id) — returning users get full context.
    - RAG pipeline retrieves relevant chunks → LLM answers ONLY from those chunks.
    - Both the user message and the assistant reply are persisted before returning.
    """
    user_id = current_user["user_id"]

    # vectorstore is loaded once at startup and stored in app.state
    vectorstore = request.app.state.vectorstore

    answer, citations = chat(
        user_id=user_id,
        user_message=body.message,
        vectorstore=vectorstore,
    )

    return ChatResponse(answer=answer, sources=citations)


@router.get("/history", response_model=HistoryResponse)
def get_history(current_user: dict = Depends(get_current_user)):
    """
    Return the full conversation history for the authenticated user.
    Useful for rendering past conversations in the frontend.
    """
    user_id  = current_user["user_id"]
    messages = load_conversation(user_id)
    return HistoryResponse(user_id=user_id, messages=messages)


@router.delete("/history", status_code=204)
def delete_history(current_user: dict = Depends(get_current_user)):
    """
    Wipe the conversation history for the authenticated user.
    The user account is NOT deleted — only the chat history.
    """
    clear_conversation(current_user["user_id"])
