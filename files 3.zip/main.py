"""
main.py
=======
FastAPI application entry point.

Startup sequence:
  1. Load the pre-built ChromaDB vectorstore into app.state.vectorstore.
     This happens ONCE at startup — all requests share the same in-memory vectorstore object.
  2. Register auth and chat routers.

Pre-requisites (run before starting the server):
  python -m services.ocr_service         # Extract text from all PDFs → combined_output.txt
  python -m services.vector_service      # Embed chunks → build ChromaDB index

Then start the server:
  uvicorn main:app --reload --host 0.0.0.0 --port 8000
"""
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from routers.auth import router as auth_router
from routers.chat import router as chat_router
from services.vector_service import build_or_load_vectorstore


# ── Lifespan (startup / shutdown) ─────────────────────────────────────────────
@asynccontextmanager
async def lifespan(app: FastAPI):
    """
    Load vectorstore ONCE at startup.
    Storing it in app.state means every request can use it without reloading.
    """
    print("[startup] Loading vectorstore...")
    app.state.vectorstore = build_or_load_vectorstore()
    print("[startup] ✅ Vectorstore ready. Server accepting requests.")
    yield
    # Shutdown cleanup (if needed)
    print("[shutdown] Server stopping.")


# ── App ───────────────────────────────────────────────────────────────────────
app = FastAPI(
    title="Gujarat Info Chatbot API",
    description=(
        "RAG-powered chatbot over scanned Gujarati Government PDFs. "
        "Answers are strictly grounded in the indexed documents — no hallucination."
    ),
    version="1.0.0",
    lifespan=lifespan,
)

# ── CORS (adjust origins for production) ──────────────────────────────────────
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],        # Restrict to your frontend URL in production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ── Routers ───────────────────────────────────────────────────────────────────
app.include_router(auth_router)
app.include_router(chat_router)


@app.get("/health", tags=["Health"])
def health():
    return {"status": "ok"}


# ── Dev runner ────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
