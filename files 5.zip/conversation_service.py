"""
services/conversation_service.py
==================================
Redis-based conversation storage keyed on user_id.

Design:
  - Frontend generates and sends user_id with every request
  - History stored in Redis under key "chat:<user_id>"
  - Same user_id  → same history always (across devices, logouts, restarts)
  - New user_id   → fresh history automatically
  - No login/auth needed at all

Redis structure per user_id:
  {
    "messages": [                   ← last MAX_HISTORY_TURNS turns
      {"role": "user",      "content": "...", "timestamp": "..."},
      {"role": "assistant", "content": "...", "timestamp": "..."}
    ],
    "summary": "..."                ← compressed older context
  }

TTL:
  Every write resets the TTL (REDIS_TTL_DAYS).
  Active users never lose history.
  Inactive users cleaned up automatically by Redis.
"""
import json
from datetime import datetime, timezone
from typing import List, Optional

import redis

from core.config import (
    REDIS_HOST,
    REDIS_PORT,
    REDIS_PASSWORD,
    REDIS_SSL,
    REDIS_TTL_DAYS,
    MAX_HISTORY_TURNS,
    AZURE_OPENAI_ENDPOINT,
    AZURE_OPENAI_KEY,
    AZURE_OPENAI_API_VERSION,
    CHAT_DEPLOYMENT,
)

# ── Redis client singleton ─────────────────────────────────────────────────────
_redis_client: Optional[redis.Redis] = None

def get_redis() -> redis.Redis:
    global _redis_client
    if _redis_client is None:
        _redis_client = redis.Redis(
            host=REDIS_HOST,
            port=REDIS_PORT,
            password=REDIS_PASSWORD,
            ssl=REDIS_SSL,
            decode_responses=True,
        )
    return _redis_client

def _key(user_id: str) -> str:
    return f"chat:{user_id}"

def _ttl() -> int:
    return REDIS_TTL_DAYS * 24 * 60 * 60


# ── Load conversation ──────────────────────────────────────────────────────────
def load_conversation(user_id: str) -> dict:
    """
    Load full conversation data for user_id.
    Returns empty structure for new users.
    """
    raw = get_redis().get(_key(user_id))
    if not raw:
        return {"messages": [], "summary": ""}
    return json.loads(raw)


# ── Save message ───────────────────────────────────────────────────────────────
def save_message(user_id: str, role: str, content: str) -> None:
    """
    Append one message to Redis. Resets TTL on every write.
    """
    r    = get_redis()
    data = load_conversation(user_id)
    data["messages"].append({
        "role":      role,
        "content":   content,
        "timestamp": datetime.now(timezone.utc).isoformat(),
    })
    r.setex(_key(user_id), _ttl(), json.dumps(data))


# ── Get recent history for LLM ─────────────────────────────────────────────────
def get_recent_history(user_id: str) -> List[dict]:
    """
    Returns last MAX_HISTORY_TURNS turns formatted for OpenAI messages array.
    Prepends summary as system message if one exists.
    This is what gets injected into the LLM prompt on every request.
    """
    data     = load_conversation(user_id)
    messages = data.get("messages", [])
    summary  = data.get("summary",  "")

    recent  = messages[-(MAX_HISTORY_TURNS * 2):]
    history = [{"role": m["role"], "content": m["content"]} for m in recent]

    if summary:
        history = [{
            "role":    "system",
            "content": f"Summary of earlier conversation:\n{summary}"
        }] + history

    return history


# ── Auto-summarize old messages ────────────────────────────────────────────────
def summarize_if_needed(user_id: str) -> None:
    """
    When messages exceed threshold, compress old ones into a summary.
    Prevents context window overflow on long conversations.
    Called automatically after every assistant reply.
    """
    data      = load_conversation(user_id)
    messages  = data.get("messages", [])
    threshold = MAX_HISTORY_TURNS * 4   # summarize when 4x limit

    if len(messages) <= threshold:
        return

    midpoint      = len(messages) // 2
    old_messages  = messages[:midpoint]
    keep_messages = messages[midpoint:]

    conversation_text = "\n".join(
        f"{m['role'].upper()}: {m['content']}" for m in old_messages
    )

    try:
        from openai import AzureOpenAI
        client = AzureOpenAI(
            api_key=AZURE_OPENAI_KEY,
            api_version=AZURE_OPENAI_API_VERSION,
            azure_endpoint=AZURE_OPENAI_ENDPOINT,
        )
        response = client.chat.completions.create(
            model=CHAT_DEPLOYMENT,
            messages=[
                {
                    "role":    "system",
                    "content": (
                        "Summarize this conversation concisely. "
                        "Include key topics, important facts, specific years "
                        "or data the user asked about. "
                        "This summary will be used as context for future messages."
                    )
                },
                {"role": "user", "content": conversation_text}
            ],
            temperature=0,
            max_tokens=500,
        )
        new_summary      = response.choices[0].message.content or ""
        existing_summary = data.get("summary", "")
        if existing_summary:
            new_summary = f"{existing_summary}\n\n{new_summary}"

        data["messages"] = keep_messages
        data["summary"]  = new_summary
        get_redis().setex(_key(user_id), _ttl(), json.dumps(data))
        print(f"[conversation] Summarized {midpoint} old messages for {user_id}")

    except Exception as e:
        print(f"[conversation] Summarization skipped: {e}")


# ── Get all messages (for /history endpoint) ───────────────────────────────────
def get_all_messages(user_id: str) -> List[dict]:
    return load_conversation(user_id).get("messages", [])


# ── Clear conversation ─────────────────────────────────────────────────────────
def clear_conversation(user_id: str) -> None:
    get_redis().delete(_key(user_id))


# ── Check if user exists ───────────────────────────────────────────────────────
def user_exists(user_id: str) -> bool:
    return get_redis().exists(_key(user_id)) > 0
