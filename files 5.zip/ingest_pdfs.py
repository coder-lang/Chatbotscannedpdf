"""
scripts/ingest_pdfs.py
=======================
One-time setup script. Run BEFORE starting the server.

  Step 1 — OCR all PDFs → combined_output.txt  (Azure Document Intelligence)
  Step 2 — Embed chunks → build ChromaDB index  (Azure OpenAI Embeddings)

Usage (from project ROOT folder):
  python scripts/ingest_pdfs.py
"""
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from services.ocr_service import process_all_pdfs
from services.vector_service import build_or_load_vectorstore
from core.config import OUTPUT_TXT_FILE


def main():
    print("=" * 60)
    print("STEP 1: OCR — Extracting text from scanned PDFs")
    print("=" * 60)
    process_all_pdfs()

    if not os.path.exists(OUTPUT_TXT_FILE):
        print(f"\nERROR: OCR output not found at: {OUTPUT_TXT_FILE}")
        sys.exit(1)

    print("\n" + "=" * 60)
    print("STEP 2: INDEXING — Building ChromaDB vectorstore")
    print("=" * 60)
    build_or_load_vectorstore()

    print("\nIngestion complete.")
    print("Now start the server:  python main.py")


if __name__ == "__main__":
    main()
