"""
services/conversation_service.py
==================================
JSON file-based conversation storage keyed on user_id.
No Redis or any external dependency needed.

Each user gets one file: conversation_store/<user_id>.json
Structure:
  {
    "messages": [
      {"role": "user",      "content": "...", "timestamp": "..."},
      {"role": "assistant", "content": "...", "timestamp": "..."}
    ],
    "summary": "..."    ← compressed older context
  }

Behavior:
  Same user_id  → same file → history continues across restarts/logouts ✅
  New user_id   → new file  → fresh conversation                        ✅
  No login/auth needed                                                   ✅
"""
import json
import os
from datetime import datetime, timezone
from typing import List, Optional

from core.config import (
    MAX_HISTORY_TURNS,
    CONVERSATIONS_DIR,
    AZURE_OPENAI_ENDPOINT,
    AZURE_OPENAI_KEY,
    AZURE_OPENAI_API_VERSION,
    CHAT_DEPLOYMENT,
)

# ── File helpers ───────────────────────────────────────────────────────────────
def _user_file(user_id: str) -> str:
    os.makedirs(CONVERSATIONS_DIR, exist_ok=True)
    return os.path.join(CONVERSATIONS_DIR, f"{user_id}.json")

def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


# ── Load conversation ──────────────────────────────────────────────────────────
def load_conversation(user_id: str) -> dict:
    """
    Load full conversation data for user_id.
    Returns empty structure for new users.
    """
    path = _user_file(user_id)
    if not os.path.exists(path):
        return {"messages": [], "summary": ""}
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


# ── Save message ───────────────────────────────────────────────────────────────
def save_message(user_id: str, role: str, content: str) -> None:
    """Append one message and write back to disk."""
    data = load_conversation(user_id)
    data["messages"].append({
        "role":      role,
        "content":   content,
        "timestamp": _now(),
    })
    with open(_user_file(user_id), "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


# ── Get recent history for LLM ─────────────────────────────────────────────────
def get_recent_history(user_id: str) -> List[dict]:
    """
    Returns last MAX_HISTORY_TURNS turns for the LLM prompt.
    Prepends summary as system message if one exists.
    """
    data     = load_conversation(user_id)
    messages = data.get("messages", [])
    summary  = data.get("summary",  "")

    recent  = messages[-(MAX_HISTORY_TURNS * 2):]
    history = [{"role": m["role"], "content": m["content"]} for m in recent]

    if summary:
        history = [{
            "role":    "system",
            "content": f"Summary of earlier conversation:\n{summary}"
        }] + history

    return history


# ── Auto-summarize old messages ────────────────────────────────────────────────
def summarize_if_needed(user_id: str) -> None:
    """
    When messages exceed threshold, compress old ones into a summary.
    Prevents context window overflow on long conversations.
    Called automatically after every assistant reply.
    """
    data      = load_conversation(user_id)
    messages  = data.get("messages", [])
    threshold = MAX_HISTORY_TURNS * 4

    if len(messages) <= threshold:
        return

    midpoint      = len(messages) // 2
    old_messages  = messages[:midpoint]
    keep_messages = messages[midpoint:]

    conversation_text = "\n".join(
        f"{m['role'].upper()}: {m['content']}" for m in old_messages
    )

    try:
        from openai import AzureOpenAI
        client = AzureOpenAI(
            api_key=AZURE_OPENAI_KEY,
            api_version=AZURE_OPENAI_API_VERSION,
            azure_endpoint=AZURE_OPENAI_ENDPOINT,
        )
        response = client.chat.completions.create(
            model=CHAT_DEPLOYMENT,
            messages=[
                {
                    "role":    "system",
                    "content": (
                        "Summarize this conversation concisely. "
                        "Include key topics, important facts, specific years "
                        "or data the user asked about. "
                        "This summary will be used as context for future messages."
                    )
                },
                {"role": "user", "content": conversation_text}
            ],
            temperature=0,
            max_tokens=500,
        )
        new_summary      = response.choices[0].message.content or ""
        existing_summary = data.get("summary", "")
        if existing_summary:
            new_summary = f"{existing_summary}\n\n{new_summary}"

        data["messages"] = keep_messages
        data["summary"]  = new_summary

        with open(_user_file(user_id), "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)

        print(f"[conversation] Summarized {midpoint} old messages for {user_id}")

    except Exception as e:
        print(f"[conversation] Summarization skipped: {e}")


# ── Get all messages (for /history endpoint) ───────────────────────────────────
def get_all_messages(user_id: str) -> List[dict]:
    return load_conversation(user_id).get("messages", [])


# ── Clear conversation ─────────────────────────────────────────────────────────
def clear_conversation(user_id: str) -> None:
    path = _user_file(user_id)
    if os.path.exists(path):
        os.remove(path)


# ── Check if user exists ───────────────────────────────────────────────────────
def user_exists(user_id: str) -> bool:
    return os.path.exists(_user_file(user_id))
