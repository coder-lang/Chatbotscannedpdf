"""
services/chat_service.py
=========================
Core RAG pipeline. Called by the /chat endpoint.

Flow for every user message:
  1. Load last N turns from persistent conversation store (per user_id)
  2. Embed the user query → vector search → top-k chunks with citations
  3. Check if retrieved context is sufficient (confidence gate)
  4. Build prompt: system + context + history + user query
  5. Call Azure OpenAI (temperature=0 for determinism)
  6. Persist user message + assistant reply
  7. Return answer + source citations

Anti-hallucination layers:
  A. temperature=0 — most deterministic output
  B. Strict system prompt — model is instructed to say "I don't know" if the
     answer is not in the retrieved context. It must NOT use outside knowledge.
  C. Context sufficiency gate — if no chunks are retrieved, return a canned
     "not found" message without calling the LLM at all.
  D. Source citations — every answer must reference doc_name + page_no so the
     user can verify.
  E. No memory_logs.clear() mid-conversation — your original code cleared memory
     when JSON was detected in the output. That caused the bot to forget context
     and start hallucinating. Removed completely.
"""
import json
from typing import List, Optional, Tuple

from openai import AzureOpenAI
from langchain_community.vectorstores import Chroma

from core.config import (
    AZURE_OPENAI_ENDPOINT,
    AZURE_OPENAI_KEY,
    AZURE_OPENAI_API_VERSION,
    CHAT_DEPLOYMENT,
    VECTOR_SEARCH_TOP_K,
)
from services.vector_service import search_vectorstore
from services.conversation_service import (
    get_recent_history,
    save_message,
)


# ── Azure OpenAI client (module-level singleton) ──────────────────────────────
_openai_client = AzureOpenAI(
    api_key=AZURE_OPENAI_KEY,
    api_version=AZURE_OPENAI_API_VERSION,
    azure_endpoint=AZURE_OPENAI_ENDPOINT,
)


# ── System prompt ──────────────────────────────────────────────────────────────
# Key anti-hallucination rules are embedded here:
#   - "Only use the provided Context" — forbids inventing facts
#   - "Cite your sources" — forces grounded answers
#   - "Say I don't know" — prevents confident wrong answers
#   - "Do not assume" — prevents gap-filling with outside knowledge
SYSTEM_PROMPT = """
You are Gujarat Info Assistant, an AI that answers questions STRICTLY based on the
Gujarat Government documents provided to you in the Context section below.

RULES — follow all of them without exception:

1. ONLY use information from the Context section. Do NOT use any outside knowledge
   or make any assumptions. If the Context does not contain the answer, respond
   exactly with: "I could not find the answer to your question in the available documents."

2. ALWAYS cite your sources at the end of your answer in this format:
   📄 Source: [Document Name: <doc>, Page: <page>]
   List every page you used.

3. For numerical questions (totals, maximums, minimums, comparisons):
   - Identify the correct table from the Context.
   - Reconstruct the table logically (OCR may have broken lines — merge them).
   - Show your working: list the values you compared, then state the answer.

4. For Gujarati text in the Context: understand it and answer in the same language
   the user used. If the user writes in English, reply in English. If in Gujarati, reply in Gujarati.

5. Keep answers concise and factual. Use bullet points for lists.

6. Do NOT guess, speculate, or extrapolate beyond what is written in the Context.

7. If the user's question is about a topic not covered by Gujarat Government documents
   (e.g., general knowledge), politely say this is outside the scope of the available documents.
""".strip()


# ── Context builder ───────────────────────────────────────────────────────────
def _build_context_block(chunks: List[dict]) -> Tuple[str, List[str]]:
    """
    Convert retrieved chunks into a formatted context string + citation list.
    Each chunk is labelled with its source so the LLM can reference it.
    """
    if not chunks:
        return "", []

    context_parts = []
    citations = []

    for i, chunk in enumerate(chunks, 1):
        doc  = chunk.get("doc_name", "unknown")
        page = chunk.get("page_no", "?")
        text = chunk.get("text", "")
        citation = f"Document: {doc}, Page: {page}"
        citations.append(citation)
        context_parts.append(
            f"[Chunk {i} | {citation}]\n{text}\n"
        )

    return "\n---\n".join(context_parts), citations


# ── Main chat function ────────────────────────────────────────────────────────
def chat(
    user_id: str,
    user_message: str,
    vectorstore: Chroma,
) -> Tuple[str, List[str]]:
    """
    Full RAG pipeline for one user turn.

    Args:
        user_id:      Unique user identifier (from JWT). Used for conversation persistence.
        user_message: The user's current query.
        vectorstore:  Pre-loaded ChromaDB instance (passed in from app state).

    Returns:
        (answer_text, citations_list)
    """
    # ── Step 1: Retrieve relevant context ─────────────────────────────────────
    chunks = search_vectorstore(
        query=user_message,
        vectorstore=vectorstore,
        k=VECTOR_SEARCH_TOP_K,
    )

    # ── Step 2: Confidence gate ────────────────────────────────────────────────
    # If no chunks at all, don't call the LLM — avoids hallucinated "confident" answers.
    if not chunks:
        no_context_reply = (
            "I could not find relevant information in the available documents "
            "to answer your question. Please try rephrasing or ask about a topic "
            "covered in the Gujarat Government documents."
        )
        save_message(user_id, "user", user_message)
        save_message(user_id, "assistant", no_context_reply)
        return no_context_reply, []

    # ── Step 3: Build context block ────────────────────────────────────────────
    context_block, citations = _build_context_block(chunks)

    # ── Step 4: Load conversation history (persistent, per-user) ───────────────
    history = get_recent_history(user_id)

    # ── Step 5: Assemble messages for Azure OpenAI ─────────────────────────────
    messages = [
        # Layer A: Strict system instructions (anti-hallucination rules)
        {"role": "system", "content": SYSTEM_PROMPT},

        # Layer B: Retrieved document context (the ONLY knowledge the LLM may use)
        {
            "role": "system",
            "content": f"Context (use ONLY this to answer):\n\n{context_block}",
        },

        # Layer C: Persistent conversation history (so returning users get continuity)
        *history,

        # Layer D: Current user message
        {"role": "user", "content": user_message},
    ]

    # ── Step 6: Call Azure OpenAI ──────────────────────────────────────────────
    # temperature=0 → deterministic, grounded responses (anti-hallucination)
    response = _openai_client.chat.completions.create(
        model=CHAT_DEPLOYMENT,
        messages=messages,
        temperature=0,          # most deterministic
        top_p=0.9,
        max_tokens=1500,
    )

    answer = response.choices[0].message.content or ""

    # ── Step 7: Persist both turns ─────────────────────────────────────────────
    # Saving to JSON files (per user_id) means history survives server restarts.
    # This replaces your original in-memory memory_logs list.
    save_message(user_id, "user", user_message)
    save_message(user_id, "assistant", answer)

    return answer, citations
